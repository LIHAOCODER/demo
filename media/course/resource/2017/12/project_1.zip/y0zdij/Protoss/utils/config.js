
class Config {
  constructor() {

  }
}

Config.restUrl = 'http://z.cn/api/v1/';

export { Config };