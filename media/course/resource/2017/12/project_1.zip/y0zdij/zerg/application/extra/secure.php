<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/5/22
 * Time: 16:36
 */

return [
    'token_salt' => '',
    'pay_back_url' => ''
//    http://2whczb.webx.cc
    //Ngrok
];