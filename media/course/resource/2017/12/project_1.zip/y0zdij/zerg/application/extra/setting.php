<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/5/12
 * Time: 10:14
 */
return [
    'img_prefix' => 'http://z.cn/images',
    'token_expire_in' => 7200
];
