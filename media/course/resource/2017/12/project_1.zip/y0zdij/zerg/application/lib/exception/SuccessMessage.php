<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/5/25
 * Time: 14:34
 */

namespace app\lib\exception;


class SuccessMessage
{
    public $code = 201;
    public $msg = 'ok';
    public $errorCode = 0;
}